﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    interface IBuyer
    {
        void BuyFood();
        public int Food { get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BirthdayCelebrations
{
    class Program
    {
        static void Main(string[] args)
        {
            var listOfBirthables = new List<IBirthdable>();
            while (true)
            {
                var input = Console.ReadLine().Split();

                if (input[0] == "End")
                {
                    break;
                }
                
                IBirthdable birthable = null;
                if (input[0] == "Citizen")
                {
                    var name = input[1];
                    var age = int.Parse(input[2]);
                    var id = input[3];
                    var birthdate = input[4];

                    birthable = new Citizen(name, age, id, birthdate);
                    listOfBirthables.Add(birthable);
                }
                else if (input[0] == "Pet")
                {
                    var name = input[1];
                    var birthdate = input[2];

                    birthable = new Pet(name, birthdate);
                    listOfBirthables.Add(birthable);
                }
            }
            var yearToSerch = Console.ReadLine();

            foreach (var birtdableItem in listOfBirthables.Where(x => x.Birthdate.EndsWith(yearToSerch)))
            {
                Console.WriteLine(birtdableItem.Birthdate);
            }
        }
    }
}

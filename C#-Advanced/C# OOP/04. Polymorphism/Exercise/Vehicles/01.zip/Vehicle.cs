﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        protected Vehicle(double fuelQuantity, double fuelConsumptionInLitersPerKm)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm;
        }

        public double FuelQuantity { get; set; }
        public double FuelConsumptionInLitersPerKm { get; set; }
        public abstract void DriveDistance(double distance);
        public abstract void RefeledAmountOfFuel(double litersOfFuel);

    }
}

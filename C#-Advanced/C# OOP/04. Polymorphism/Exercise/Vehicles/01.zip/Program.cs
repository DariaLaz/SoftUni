﻿using System;

namespace Vehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            var carLine = Console.ReadLine().Split();
            var car = new Car(double.Parse(carLine[1]), double.Parse(carLine[2]));
            var truckLine = Console.ReadLine().Split();
            var truck = new Truck(double.Parse(truckLine[1]), double.Parse(truckLine[2]));

            var n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine().Split();
                if (input[0] == "Drive")
                {
                    var distance = double.Parse(input[2]);
                    if (input[1] == "Car")
                    {
                       
                        if (car.FuelQuantity >=  distance * car.FuelConsumptionInLitersPerKm)
                        {
                            car.DriveDistance(distance);
                            Console.WriteLine($"Car travelled {distance} km");
                        }
                        else
                        {
                            Console.WriteLine("Car needs refueling");
                        }
                    }
                    else if (input[1] == "Truck")
                    {
                        if (truck.FuelQuantity >= distance * truck.FuelConsumptionInLitersPerKm)
                        {
                            truck.DriveDistance(distance);
                            Console.WriteLine($"Truck travelled {distance} km");
                        }
                        else
                        {
                            Console.WriteLine("Truck needs refueling");
                        }
                       
                    }
                }
                else if (input[0] == "Refuel")
                {
                    if (input[1] == "Car")
                    {
                        car.RefeledAmountOfFuel(double.Parse(input[2]));
                    }
                    else if (input[1] == "Truck")
                    {
                        truck.RefeledAmountOfFuel(double.Parse(input[2]));
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity :f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity :f2}");
        }
    }
}

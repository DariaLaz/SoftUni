﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsumptionInLitersPerKm)
             : base(fuelQuantity, fuelConsumptionInLitersPerKm + 1.6)
        {
        }

        public override void DriveDistance(double distance)
        {
            FuelQuantity -= (distance * FuelConsumptionInLitersPerKm);
        }

        public override void RefeledAmountOfFuel(double litersOfFuel)
        {
            FuelQuantity += (0.95 * litersOfFuel);
        }
    }
}
